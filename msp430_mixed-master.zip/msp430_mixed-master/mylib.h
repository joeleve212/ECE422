/*
 * mylib.h
 *
 *  Created on: Feb 1, 2016
 *      Author: Jason
 */

#ifndef _MYLIB_H
#define _MYLIB_H

int add(int addend, int adder);
int subtract(int num, int numToSubtract);

#endif
