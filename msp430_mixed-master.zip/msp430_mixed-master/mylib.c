/*
 * mylib.c
 *
 *  Created on: Feb 1, 2016
 *      Author: Jason
 */

#ifndef _MYLIB_H
#define _MYLIB_H

int subtract(int num, int numToSubtract){
	return num - numToSubtract;
}

#endif
