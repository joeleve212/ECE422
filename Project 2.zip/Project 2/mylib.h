/*
 * ECE 422 Project 2
 * Joanthan Bayert and Joe Leville
 * mylib.h
 *
 *  multiplies two numbers through the peripheral
 */

#ifndef _MYLIB_H
#define _MYLIB_H

long int multiply(int one,int two);

#endif
